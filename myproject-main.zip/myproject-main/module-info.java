import java.awt.Color;

module LoanAssistant {
	exports loanassistant;
}
Color lightYellow = new Color(255, 255, 128);
boolean computePayment;